def get_paper_name(n: int):
    return 'papers/federalist_' + str(n) + '.txt'


def test_get_paper_name():
    assert get_paper_name(15) == 'papers/federalist_15.txt'
    assert get_paper_name(3) == 'papers/federalist_3.txt'
    print('test_get_paper_name() successful')


def get_paper_text(n: int):
    file = open(get_paper_name(n))
    text = file.read()
    file.close()
    return text


def test_get_paper_text():
    text = get_paper_text(15)
    assert len(text) == 18513
    assert 'It has its origin in the love of power.' in text
    print('test_get_paper_text() successful')


def average_word_length(words: list[str]):
    assert len(words) > 0
    total = 0
    for w in words:
        total += len(w)
    return total / len(words)


def test_average_word_length():
    eps = 1e-7
    data = [(['a', 'ab', 'abc'], 2.0),
            (['a', 'b', 'c'], 1.0),
            (['a', 'ab', 'abc', 'abcd'], 2.5),
            (['a'], 1.0),
            ]
    for words, expected_avg in data:
        calculated_avg = average_word_length(words)
        msg = (str(words) + ' expected avg ' + str(expected_avg) +
               ' but calculated avg ' + str(calculated_avg))
        assert abs(calculated_avg - expected_avg) < eps, msg
    print('test_average_word_length() successful')


def paper_avg_word_len(n: int):
    text = get_paper_text(n)
    words = text.split()
    avg_wd_len = average_word_length(words)
    return avg_wd_len


def test_paper_avg_word_len():
    eps = 1e-7
    expected_vals = [4.874692874692875,
                     5.029011249259917,
                     5.031313818924438,
                     4.930639324487334,
                     5.125730994152047]
    for n in range(1, 6):
        calculated_avg = paper_avg_word_len(n)
        expected_avg = expected_vals[n - 1]
        msg = ('Paper' + str(n) + ' expected avg ' + str(expected_avg) +
               ' but calculated avg ' + str(calculated_avg))
        assert abs(calculated_avg - expected_avg) < eps, msg
    print('test_paper_avg_word_len() successful')


def collection_avg_word_len(paper_nums: list[int]):
    total = 0.0
    for n in paper_nums:
        avg_word_len = paper_avg_word_len(n)
        total += avg_word_len
    return total / len(paper_nums)


def test_collection_avg_word_len():
    eps = 1e-7
    expected_vals = [4.874692874692875,
                     4.951852061976396,
                     4.97833931429241,
                     4.966414316841141, ]
    for max_paper_num in range(1, 5):
        paper_nums = list(range(1, max_paper_num + 1))
        calculated_avg = collection_avg_word_len(paper_nums)
        expected_avg = expected_vals[max_paper_num - 1]
        msg = ('Papers 1-' + str(max_paper_num) + ' expected avg ' + str(expected_avg) +
               ' but calculated avg ' + str(calculated_avg))
        assert abs(calculated_avg - expected_avg) < eps, msg
    print('test_collection_avg_word_len() successful')


def guess_paper_by_word_len(n):
    # Hardcoded values is bad practice but keeps the code simple.
    jay_low = 4.953895560541891
    jay_high = 5.0261243024077356
    avg_word_len = paper_avg_word_len(n)
    if avg_word_len < jay_low:
        guess = 'Hamilton'
    elif avg_word_len < jay_high:
        guess = 'Madison'
    else:
        guess = 'Jay'
    return guess


def test_guess_paper_by_word_len():
    expected_vals = ['Hamilton', 'Jay', 'Jay', 'Hamilton', 'Jay', 'Jay', 'Jay', 'Jay',
                     'Jay', 'Madison', 'Madison', 'Madison', 'Madison', 'Hamilton',
                     'Hamilton', 'Hamilton', 'Jay', 'Jay', 'Jay']
    for n in range(1, 20):
        calculated_author = guess_paper_by_word_len(n)
        expected_author = expected_vals[n - 1]
        msg = ('Paper' + str(n) + ' expected author ' + str(expected_author) +
               ' but calculated author ' + str(calculated_author))
        assert calculated_author == expected_author, msg
    print('test_paper_avg_word_len() successful')


def analyze_avg_word_len(jay, madison, hamilton, unknown):
    jay_avg = collection_avg_word_len(jay)
    madison_avg = collection_avg_word_len(madison)
    hamilton_avg = collection_avg_word_len(hamilton)
    print('jay', jay_avg)
    print('madison', madison_avg)
    print('hamilton', hamilton_avg)
    jay_low = (jay_avg + hamilton_avg) / 2
    jay_high = (jay_avg + madison_avg) / 2
    print('jay_low', jay_low, 'jay_high', jay_high)
    for paper in jay:
        avg_word_len = paper_avg_word_len(paper)
        guess = guess_paper_by_word_len(paper)
        print('Jay paper', paper, 'avg_word_len', avg_word_len, 'guess', guess)
    for paper in madison:
        avg_word_len = paper_avg_word_len(paper)
        guess = guess_paper_by_word_len(paper)
        print('Madison paper', paper, 'avg_word_len', avg_word_len, 'guess', guess)


def get_word_counts(words: list[str]):
    counts = dict()
    for w in words:
        if w not in counts:
            counts[w] = 1
        else:
            counts[w] += 1
    return counts

def test_get_word_counts():
    data = [(['a', 'a', 'a'], {'a': 3}),
            (['a', 'b', 'a', 'b', 'a'], {'a': 3, 'b': 2}),
            (['a', 'b', 'a', 'cccc', 'b', 'a'], {'a': 3, 'b': 2, 'cccc': 1}),
            ]

    for words, expected_counts in data:
        calculated_counts = get_word_counts(words)
        msg = ('Word list' + str(words) + ' expected counts ' + str(expected_counts) +
               ' but calculated ' + str(calculated_counts))
        assert calculated_counts == expected_counts, msg
    print('test_get_word_counts() successful')



def type_token_ratio(words: list[str]):
    assert len(words) > 0
    counts = get_word_counts(words)
    return len(counts) / len(words)

def test_type_token_ratio():
    eps = 1e-7
    data = [(['the', 'orange', 'cat', 'sat', 'on', 'the', 'orange', 'mat'], 0.75),
            (['a', 'a', 'a'], 1 / 3),
            (['a', 'b', 'c'], 1.0),
            (['a', 'ab', 'ab', 'abc', 'abcd'], 0.8),
            (['a'], 1.0),
            ]
    for words, expected in data:
        calculated = type_token_ratio(words)
        msg = (str(words) + ' expected type_token_ratio ' + str(expected) +
               ' but calculated type_token_ratio ' + str(calculated))
        assert abs(calculated - expected) < eps, msg
    print('test_type_token_ratio() successful')

jay_papers = [2, 3, 4, 5, 64]
madison_papers = [10, 14, 18, 19, 20, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48]
hamilton_papers = [1, 6, 7, 8, 9, 11, 12, 13, 15, 16, 17, 21, 22, 23, 24,
                   25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 59, 60,
                   61, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77,
                   78, 79, 80, 81, 82, 83, 84, 85]
unknown_papers = [49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 62, 63]

test_get_paper_name()
test_get_paper_text()
test_average_word_length()
test_paper_avg_word_len()
test_collection_avg_word_len()
# analyze_avg_word_len(jay_papers, madison_papers, hamilton_papers, unknown_papers)
test_guess_paper_by_word_len()
test_get_word_counts()
test_type_token_ratio()
